Seat-BA Fix Pack v6

What it fixes
- Next.js 15 Route Handler type-check error:
  Route "app/api/cases/[id]/route.ts" has an invalid "GET" export:
  Type "Ctx" is not a valid type for the function's second argument.

What it changes
- Only patches: app/api/cases/[id]/route.ts
- Removes a named Ctx type/interface if present.
- Replaces "ctx: Ctx" / "context: Ctx" with:
  { params }: { params: { id: string } }
- Rewrites ctx.params / context.params usages to params

How to apply (run in project root)
  unzip -o seat-ba-fix-pack-v6.zip
  bash apply-fixes-v6.sh
  rm -rf .next
  npm run build

Rollback
- A backup is created under .fix-backup-YYYYMMDD-HHMMSS/
